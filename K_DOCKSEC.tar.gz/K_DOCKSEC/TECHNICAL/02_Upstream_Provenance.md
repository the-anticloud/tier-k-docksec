# Upstream Provenance

**Project:** `K_DOCKSEC`  
**Tier:** TIER_6_SECURITY_EVAL  
**Identity:** Upstream `aquasecurity/trivy` @ `3a1b311e63a1` (Apache-2.0)

## Recorded identity

| Fact | Value |
| --- | --- |
| Upstream | `aquasecurity/trivy` |
| Commit | `3a1b311e63a1b64ab3221bf52683581b77187198` |
| Upstream licence | Apache-2.0 |
| Licence class | permissive |
| Clone size | 90.44 MB |
| Ledger | 0 blocks, chain verified |
| Current TRL | NOT YET MEASURED |
| Post-optimisation TRL | NOT YET MEASURED |
| II budget cap | 1500.0 IIU |
| Verified upstream edits | 1 |

## Obligation

`K_DOCKSEC` is vendored under Apache-2.0 (permissive). Any Anticloud edit to
the vendored tree is a derivative work and is tracked in
`anticloud-edits.json`; the notice of changes is at the project `NOTICE.md`.
Where the licence class is `unknown`, no edit may be applied until the
licence is identified, because the absence of a licence is not a grant.
